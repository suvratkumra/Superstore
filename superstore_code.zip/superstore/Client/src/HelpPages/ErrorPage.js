import React from 'react'

export default function ErrorPage() {
  return (
    <div>
        ERROR! The requested page does not exist.
    </div>
  )
}